// JS asociado a html

//alert("js externo");